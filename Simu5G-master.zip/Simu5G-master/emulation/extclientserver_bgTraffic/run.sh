#!/bin/bash
# make sure you run '. setenv' in the Simu5G root directory before running this script
#   


# run simulation
simu5g -u Cmdenv -c ExtClientServer-bgTraffic $*


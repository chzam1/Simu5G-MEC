:hide-footer:

Contacts
========

| *Giovanni Nardini*:  giovanni.nardini\ :si-icon:`material/at`\ unipi.it
| *Giovanni Stea*:  giovanni.stea\ :si-icon:`material/at`\ unipi.it
| *Antonio Virdis*:  antonio.virdis\ :si-icon:`material/at`\ unipi.it

Follow Simu5G updates on
`ResearchGate <https://www.researchgate.net/project/Simu5G>`__ and
`Twitter <https://twitter.com/Simu5G>`__.

If you need help with the code, send a message on the `OMNeT++
Users forum <https://forum.omnetpp.org>`__ and
get help from the community.

If you found a bug in the code, please `open an issue on
GitHub <https://github.com/Unipisa/Simu5G/issues>`__.
